# JARVIS Smart Mobile Assistant

GitHub Pages-ready JARVIS build.

## Publish
1. Create a GitHub repository.
2. Upload `index.html`.
3. Go to Settings → Pages.
4. Choose Deploy from a branch → `main` → `/ (root)` → Save.
5. Open the generated HTTPS `github.io` URL in Chrome.
6. Tap the JARVIS mic and choose Allow.

## AI
Supports Poe API and OpenAI API from the AI settings panel.

## Security
For personal testing, the browser version stores the API key in localStorage. Do not publish a real API key in a public repository. A secure backend is recommended for a public deployment.
